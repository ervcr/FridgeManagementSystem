﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace frideFixHub.Migrations
{
    /// <inheritdoc />
    public partial class tbbb : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Service_Fridge_FridgeId",
                table: "Service");

            migrationBuilder.RenameColumn(
                name: "FridgeId",
                table: "Service",
                newName: "FaultId");

            migrationBuilder.RenameIndex(
                name: "IX_Service_FridgeId",
                table: "Service",
                newName: "IX_Service_FaultId");

            migrationBuilder.AddForeignKey(
                name: "FK_Service_Fridge_FaultId",
                table: "Service",
                column: "FaultId",
                principalTable: "Fridge",
                principalColumn: "FridgeId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Service_Fridge_FaultId",
                table: "Service");

            migrationBuilder.RenameColumn(
                name: "FaultId",
                table: "Service",
                newName: "FridgeId");

            migrationBuilder.RenameIndex(
                name: "IX_Service_FaultId",
                table: "Service",
                newName: "IX_Service_FridgeId");

            migrationBuilder.AddForeignKey(
                name: "FK_Service_Fridge_FridgeId",
                table: "Service",
                column: "FridgeId",
                principalTable: "Fridge",
                principalColumn: "FridgeId");
        }
    }
}
