﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using frideFixHub.Areas.Identity.Data;
using frideFixHub.Models;

namespace frideFixHub.Controllers
{
    public class MaintenanceHistoriesController : Controller
    {
        private readonly frideFixHubDBContext _context;

        public MaintenanceHistoriesController(frideFixHubDBContext context)
        {
            _context = context;
        }

        // GET: MaintenanceHistories
        public async Task<IActionResult> Index()
        {
            var frideFixHubDBContext = _context.MaintenanceHistory.Include(m => m.Maintenance);
            return View(await frideFixHubDBContext.ToListAsync());
        }

        // GET: MaintenanceHistories/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var maintenanceHistory = await _context.MaintenanceHistory
                .Include(m => m.Maintenance)
                .FirstOrDefaultAsync(m => m.HistoryId == id);
            if (maintenanceHistory == null)
            {
                return NotFound();
            }

            return View(maintenanceHistory);
        }

        // GET: MaintenanceHistories/Create
        public IActionResult Create()
        {
            ViewData["MaintenanceId"] = new SelectList(_context.Maintenance, "MaintenanceId", "MaintenanceId");
            return View();
        }

        // POST: MaintenanceHistories/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("HistoryId,Details,HistoryDate,MaintenanceId")] MaintenanceHistory maintenanceHistory)
        {
            if (ModelState.IsValid)
            {
                _context.Add(maintenanceHistory);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MaintenanceId"] = new SelectList(_context.Maintenance, "MaintenanceId", "MaintenanceId", maintenanceHistory.MaintenanceId);
            return View(maintenanceHistory);
        }

        // GET: MaintenanceHistories/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var maintenanceHistory = await _context.MaintenanceHistory.FindAsync(id);
            if (maintenanceHistory == null)
            {
                return NotFound();
            }
            ViewData["MaintenanceId"] = new SelectList(_context.Maintenance, "MaintenanceId", "MaintenanceId", maintenanceHistory.MaintenanceId);
            return View(maintenanceHistory);
        }

        // POST: MaintenanceHistories/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("HistoryId,Details,HistoryDate,MaintenanceId")] MaintenanceHistory maintenanceHistory)
        {
            if (id != maintenanceHistory.HistoryId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(maintenanceHistory);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MaintenanceHistoryExists(maintenanceHistory.HistoryId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MaintenanceId"] = new SelectList(_context.Maintenance, "MaintenanceId", "MaintenanceId", maintenanceHistory.MaintenanceId);
            return View(maintenanceHistory);
        }

        // GET: MaintenanceHistories/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var maintenanceHistory = await _context.MaintenanceHistory
                .Include(m => m.Maintenance)
                .FirstOrDefaultAsync(m => m.HistoryId == id);
            if (maintenanceHistory == null)
            {
                return NotFound();
            }

            return View(maintenanceHistory);
        }

        // POST: MaintenanceHistories/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var maintenanceHistory = await _context.MaintenanceHistory.FindAsync(id);
            if (maintenanceHistory != null)
            {
                _context.MaintenanceHistory.Remove(maintenanceHistory);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MaintenanceHistoryExists(int id)
        {
            return _context.MaintenanceHistory.Any(e => e.HistoryId == id);
        }
    }
}
