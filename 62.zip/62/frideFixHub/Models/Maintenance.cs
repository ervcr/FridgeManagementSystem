﻿using frideFixHub.Areas.Identity.Data;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace frideFixHub.Models
{
    public class Maintenance
    {
        [Key]
        public int MaintenanceId { get; set; }
        public string? Technician { get; set; }
        public DateTime? VisitDate { get; set; }
        public string? Notes { get; set; }

        // Foreign Key: Link to FridgeFault
        [ForeignKey("FridgeFault")]
        public int? FaultId { get; set; }
        public FridgeFault? FridgeFault { get; set; }

        // Relationship: Each maintenance can have a history
        public MaintenanceHistory? MaintenanceHistory { get; set; }

        public frideFixHubUser? User { get; set; }
        public string? MAINTAINANCETECHNICIAN { get; set; }


    }
}
