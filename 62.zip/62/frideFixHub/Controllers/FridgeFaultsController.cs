﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using frideFixHub.Areas.Identity.Data;
using frideFixHub.Models;

namespace frideFixHub.Controllers
{
    public class FridgeFaultsController : Controller
    {
        private readonly frideFixHubDBContext _context;

        public FridgeFaultsController(frideFixHubDBContext context)
        {
            _context = context;
        }

        // GET: FridgeFaults
        public async Task<IActionResult> Index()
        {
            var frideFixHubDBContext = _context.FridgeFault.Include(f => f.Fridge);
            return View(await frideFixHubDBContext.ToListAsync());
        }

        // GET: FridgeFaults/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fridgeFault = await _context.FridgeFault
                .Include(f => f.Fridge)
                .FirstOrDefaultAsync(m => m.FaultId == id);
            if (fridgeFault == null)
            {
                return NotFound();
            }

            return View(fridgeFault);
        }

        // GET: FridgeFaults/Create
        public IActionResult Create()
        {
            ViewData["FridgeId"] = new SelectList(_context.Fridge, "FridgeId", "FridgeId");
            return View();
        }

        // POST: FridgeFaults/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("FaultId,Description,FaultDate,FridgeId")] FridgeFault fridgeFault)
        {
            if (ModelState.IsValid)
            {
                _context.Add(fridgeFault);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["FridgeId"] = new SelectList(_context.Fridge, "FridgeId", "FridgeId", fridgeFault.FridgeId);
            return View(fridgeFault);
        }

        // GET: FridgeFaults/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fridgeFault = await _context.FridgeFault.FindAsync(id);
            if (fridgeFault == null)
            {
                return NotFound();
            }
            ViewData["FridgeId"] = new SelectList(_context.Fridge, "FridgeId", "FridgeId", fridgeFault.FridgeId);
            return View(fridgeFault);
        }

        // POST: FridgeFaults/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("FaultId,Description,FaultDate,FridgeId")] FridgeFault fridgeFault)
        {
            if (id != fridgeFault.FaultId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(fridgeFault);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!FridgeFaultExists(fridgeFault.FaultId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["FridgeId"] = new SelectList(_context.Fridge, "FridgeId", "FridgeId", fridgeFault.FridgeId);
            return View(fridgeFault);
        }

        // GET: FridgeFaults/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var fridgeFault = await _context.FridgeFault
                .Include(f => f.Fridge)
                .FirstOrDefaultAsync(m => m.FaultId == id);
            if (fridgeFault == null)
            {
                return NotFound();
            }

            return View(fridgeFault);
        }

        // POST: FridgeFaults/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var fridgeFault = await _context.FridgeFault.FindAsync(id);
            if (fridgeFault != null)
            {
                _context.FridgeFault.Remove(fridgeFault);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool FridgeFaultExists(int id)
        {
            return _context.FridgeFault.Any(e => e.FaultId == id);
        }
    }
}
