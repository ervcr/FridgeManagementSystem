﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace frideFixHub.Models
{
    public class MaintenanceVisit
    {
        [Key]
        public int VisitId { get; set; }
        public DateTime? VisitDate { get; set; }
        public string? Technician { get; set; }
        public string? Remarks { get; set; }

        // Foreign Key: Link to Maintenance
        [ForeignKey("Maintenance")]
        public int? MaintenanceId { get; set; }
        public Maintenance? Maintenance { get; set; }
    }
}
