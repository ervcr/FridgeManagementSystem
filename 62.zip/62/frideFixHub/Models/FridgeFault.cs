﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace frideFixHub.Models
{
    public class FridgeFault
    {
        [Key]
        public int FaultId { get; set; }
        public string? Description { get; set; }
        public DateTime? FaultDate { get; set; }

        // Foreign Key: Link back to the fridge
        [ForeignKey("Fridge")]
        public int? FridgeId { get; set; }
        public Fridge? Fridge { get; set; }

    }
}
