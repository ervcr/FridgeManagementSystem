﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace frideFixHub.Models
{
    public class MaintenanceHistory
    {
        [Key]
        public int HistoryId { get; set; }
        public string? Details { get; set; }
        public DateTime? HistoryDate { get; set; }

        // Foreign Key: Link to Maintenance
        [ForeignKey("Maintenance")]
        public int? MaintenanceId { get; set; }
        public Maintenance? Maintenance { get; set; }

    }
}
