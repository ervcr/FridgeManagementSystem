﻿using frideFixHub.Areas.Identity.Data;
using System.ComponentModel.DataAnnotations;

namespace frideFixHub.Models
{
    public class Fridge
    {
        [Key]
        public int FridgeId { get; set; }
        public string? Brand { get; set; }
        public string? Model { get; set; }

        public frideFixHubUser? User { get; set; }
        public string? customer { get; set; }

    }
}
