﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using frideFixHub.Areas.Identity.Data;
using frideFixHub.Models;

namespace frideFixHub.Controllers
{
    public class MaintenanceVisitsController : Controller
    {
        private readonly frideFixHubDBContext _context;

        public MaintenanceVisitsController(frideFixHubDBContext context)
        {
            _context = context;
        }

        // GET: MaintenanceVisits
        public async Task<IActionResult> Index()
        {
            var frideFixHubDBContext = _context.MaintenanceVisit.Include(m => m.Maintenance);
            return View(await frideFixHubDBContext.ToListAsync());
        }

        // GET: MaintenanceVisits/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var maintenanceVisit = await _context.MaintenanceVisit
                .Include(m => m.Maintenance)
                .FirstOrDefaultAsync(m => m.VisitId == id);
            if (maintenanceVisit == null)
            {
                return NotFound();
            }

            return View(maintenanceVisit);
        }

        // GET: MaintenanceVisits/Create
        public IActionResult Create()
        {
            ViewData["MaintenanceId"] = new SelectList(_context.Maintenance, "MaintenanceId", "MaintenanceId");
            return View();
        }

        // POST: MaintenanceVisits/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("VisitId,VisitDate,Technician,Remarks,MaintenanceId")] MaintenanceVisit maintenanceVisit)
        {
            if (ModelState.IsValid)
            {
                _context.Add(maintenanceVisit);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            ViewData["MaintenanceId"] = new SelectList(_context.Maintenance, "MaintenanceId", "MaintenanceId", maintenanceVisit.MaintenanceId);
            return View(maintenanceVisit);
        }

        // GET: MaintenanceVisits/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var maintenanceVisit = await _context.MaintenanceVisit.FindAsync(id);
            if (maintenanceVisit == null)
            {
                return NotFound();
            }
            ViewData["MaintenanceId"] = new SelectList(_context.Maintenance, "MaintenanceId", "MaintenanceId", maintenanceVisit.MaintenanceId);
            return View(maintenanceVisit);
        }

        // POST: MaintenanceVisits/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("VisitId,VisitDate,Technician,Remarks,MaintenanceId")] MaintenanceVisit maintenanceVisit)
        {
            if (id != maintenanceVisit.VisitId)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(maintenanceVisit);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!MaintenanceVisitExists(maintenanceVisit.VisitId))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            ViewData["MaintenanceId"] = new SelectList(_context.Maintenance, "MaintenanceId", "MaintenanceId", maintenanceVisit.MaintenanceId);
            return View(maintenanceVisit);
        }

        // GET: MaintenanceVisits/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null)
            {
                return NotFound();
            }

            var maintenanceVisit = await _context.MaintenanceVisit
                .Include(m => m.Maintenance)
                .FirstOrDefaultAsync(m => m.VisitId == id);
            if (maintenanceVisit == null)
            {
                return NotFound();
            }

            return View(maintenanceVisit);
        }

        // POST: MaintenanceVisits/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var maintenanceVisit = await _context.MaintenanceVisit.FindAsync(id);
            if (maintenanceVisit != null)
            {
                _context.MaintenanceVisit.Remove(maintenanceVisit);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool MaintenanceVisitExists(int id)
        {
            return _context.MaintenanceVisit.Any(e => e.VisitId == id);
        }
    }
}
