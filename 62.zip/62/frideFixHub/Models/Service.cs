﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace frideFixHub.Models
{
    public class Service
    {
        [Key]
        public int ServiceId { get; set; }
        public string? ServiceType { get; set; }

        // Foreign Key: Link to Fridge
        [ForeignKey("FridgeFault")]
        public int? FaultId { get; set; }
        public Fridge? FridgeFault { get; set; }
    }
}
